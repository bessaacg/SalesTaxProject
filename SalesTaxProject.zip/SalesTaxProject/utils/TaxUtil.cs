﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.utils
{
    public class TaxUtil
    {
        private const decimal ROUND_OFF = 0.05M;

        
        // Rounds off a double value to the nearest 0.05
        
		public static decimal RoundingOff(decimal value)
        {
            return (int)(value / ROUND_OFF + 0.5M) * 0.05M;
        }

        public static decimal Truncate(decimal value)
        {
            string result = value.ToString("N2"); 
            return Decimal.Parse(result);
        }

		public static bool ParseBoolean(char value)
		{
			bool flag = true;
			bool booleanValue = false;

			if (flag)
			{
				//parses 'Y' into 'true'
				if (value == 'Y' || value == 'y')
				{
					booleanValue = true;
					flag = false;
				}

				//parses 'N' into 'false'
				else if (value == 'N' || value == 'n')
				{
					booleanValue = false;
					flag = false;
				}

				//validates user input
				else
				{
					Console.WriteLine("Invalid input. Please Respond by (Y/N)");
				}
			}

			return booleanValue;
		}
	}
}
