﻿using SalesTaxProject.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Shopping
{
    public class ShoppingCart
    {
        private List<Item> itemList { get; set; }

        public ShoppingCart()
        {
            itemList = new List<Item>();
        }

        public void AddItemToCart(Item item)
        {
            itemList.Add(item);
        }

        public List<Item> GetItemsFromCart()
        {
            return itemList;
        }

        public int GetCartSize()
        {
            return itemList.Count;
        }
    }
}
