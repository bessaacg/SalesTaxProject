﻿using SalesTaxProject.Billing;
using SalesTaxProject.Items;
using SalesTaxProject.utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesTaxProject.Shopping;
using System.Threading;

namespace SalesTaxProject.Shopping
{
    public class Store
    {
        private ShoppingCart shoppingCart;
        private StoreShelf storeShelf;
        private PaymentCounter paymentCounter;

        string Name;
        decimal Price;
        bool Import;
        int Quantity;
        private string Country;

        public Store()
        {
            Country = "Local";
            shoppingCart = new ShoppingCart();
            paymentCounter = new PaymentCounter(Country);
            storeShelf = new StoreShelf();
        }

        public void RetrieveOrderAndPlaceInCart(string Name, decimal Price, bool Import, int Quantity)
        {
            Item item = storeShelf.SearchAndRetrieveItemFromShelf(Name.ToLower(), Price, Import, Quantity);
            shoppingCart.AddItemToCart(item);
        }

        public void SalesOrder()
        {
            do
            {
                Name = GetItemName();
                Price = GetItemPrice();
                Import = IsImport();
                Quantity = GetQuantity();
                RetrieveOrderAndPlaceInCart(Name, Price, Import, Quantity);
            }
            while (AdditionOfAnotherItem());
        }

        public void CheckOut()
        {
            paymentCounter.BillItemsInCart(shoppingCart);
            Receipt receipt = paymentCounter.GetReceipt();
            paymentCounter.PrintReceipt(receipt);
        }

        public string GetItemName()
        {
            Dictionary<string, SalesTaxProject.Items.Item> availableItems = storeShelf.items;

            Console.WriteLine(String.Join("|| ", availableItems.Keys.ToArray()));
            
            Console.Write("\nEnter item from the list above: ");
            
            string chosenItem = Console.ReadLine().Trim();

			if (!availableItems.ContainsKey(chosenItem.ToLower()))
			{
                Console.WriteLine("{0} is not in stock stock\n", chosenItem);
                chosenItem = GetItemName();
			}

            return chosenItem;
        }

        public decimal GetItemPrice()
        {
            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            
            Console.Write("Enter {0} price: ", Name);

            var input = Console.ReadLine();
            decimal price;

            while (!(decimal.TryParse(input, out price)))
            {
                Console.WriteLine("Invalid price. Price should be numeric");
                
                Console.Write("Enter {0} price: ", Name);
                input = Console.ReadLine();
            }

            return price;
        }

        public bool IsImport()
        {
            Console.Write("Is item an import or not? (Y/N): ");
            var input = Console.ReadLine();
            bool isValid = false;
            while (!isValid)
            {
                isValid = (input == "Y" || input == "y" 
                    || input == "N" || input == "n") ? true
                            : false;

                if (isValid == false)
                {
                    Console.WriteLine("Invalid input. Respond by (Y/N)");
                    IsImport();
                }
                break;
            }

            return (input == "Y" || input == "y") ? true : false;
        }

        public int GetQuantity()
        {
            Console.Write("Enter {0} quantity: ", Name);
            var input = Console.ReadLine();
            int quantity;
            while (!(int.TryParse(input, out quantity)))
            {
                Console.WriteLine("Invalid input. Enter an integer");
                Console.Write("Enter {0} quantity: ", Name);
                input = Console.ReadLine();
            }
            return quantity;
        }

        public bool AdditionOfAnotherItem()
        {
            Console.Write("\nDo you want to add another Item?(Y/N)? : ");
            var input = Console.ReadLine();

            Console.WriteLine(); 

            while (!(input == "Y" || input == "y"
                || input == "N" || input == "n"))
            {
                Console.WriteLine("Invalid input. Respond by (Y/N)");
                Console.Write("\nDo you want to add another Item?(Y/N)? : ");
                input = Console.ReadLine();
            }

            bool addAnotherItem = TaxUtil.ParseBoolean(Convert.ToChar(input));
            return addAnotherItem;
        }
    }
}
