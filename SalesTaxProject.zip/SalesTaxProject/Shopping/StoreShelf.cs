﻿using SalesTaxProject.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Shopping
{
    public class StoreShelf
    {
        public readonly Dictionary<string, Item> items;

        public StoreShelf()
        {
            items = new Dictionary<string, Item>();
            AddItemsToShelf("book", new Book());
            AddItemsToShelf("music cd", new Miscellaneous());
            AddItemsToShelf("chocolate bar", new Food());
            AddItemsToShelf("box of chocolates", new Food());
            AddItemsToShelf("bottle of perfume", new Miscellaneous());
            AddItemsToShelf("packet of headache pills", new Medical());
        }

        public void AddItemsToShelf(string item, Item itemCategory)
        {
            items.Add(item, itemCategory);
        }

        public Item SearchAndRetrieveItemFromShelf(string Name, decimal Price, bool Import, int Quantity)
        {
            Item item = items[Name].GetFactory().CreateItem(Name, Price, Import, Quantity);
            return item;
        }

        public int GetShelfSize()
        {
            return items.Count;
        }
    }
}
