﻿using SalesTaxProject.Items;
using SalesTaxProject.TaxCalculations;
using SalesTaxProject.utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Billing
{
    public class Biller
    {
        ITaxCalculator taxCalculator;

        public Biller(ITaxCalculator taxCalc)
        {
            taxCalculator = taxCalc;
        }

        public decimal CalculateTax(decimal Price, decimal Tax, bool Import)
        {
            decimal totalItemTax = taxCalculator.CalculateTax(Price, Tax, Import);
            return totalItemTax;
        }

        public decimal CalcTotalProductCost(decimal Price, decimal Tax)
        {
            return TaxUtil.Truncate(Price + Tax);
        }

        public decimal CalcTotalTax(List<Item> ProdList)
        {
            decimal totalTax = 0.0M;

            foreach (Item p in ProdList)
            {
                totalTax += (p.TaxedCost - p.Price);
            }

            return TaxUtil.Truncate(totalTax);
        }

        public decimal CalculateTotalAmount(List<Item> itemList)
        {
            decimal totalAmount = 0.0M;

            foreach (Item p in itemList)
            {
                totalAmount += p.TaxedCost;
            }

            return TaxUtil.Truncate(totalAmount);
        }

        public Receipt CreateNewReceipt(List<Item> itemList, decimal totalTax, decimal totalAmount)
        {
            return new Receipt(itemList, totalTax, totalAmount);
        }

        public void GenerateReceipt(Receipt r)
        {
            Console.WriteLine(r.ToString());
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("===================================");
            Console.ResetColor();
        }

    }
}
