﻿using SalesTaxProject.Items;
using SalesTaxProject.Shopping;
using SalesTaxProject.TaxCalculations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Billing
{
    public class PaymentCounter
    {
        private Biller Biller;
        private Receipt Receipt;
        private List<Item> ItemList;
        private string Country;

        public PaymentCounter(string Country)
        {
            this.Country = Country;
        }

        public void BillItemsInCart(ShoppingCart Cart)
        {
            ItemList = Cart.GetItemsFromCart();

            foreach (Item p in ItemList)
            {
                Biller = GetBiller(Country);
                decimal itemTax = Biller.CalculateTax(p.Price, p.GetTaxValue(Country), p.Import);
                decimal taxedCost = Biller.CalcTotalProductCost(p.Price, itemTax);
                p.TaxedCost = taxedCost;
            }
        }

        public Receipt GetReceipt()
        {
            decimal totalTax = Biller.CalcTotalTax(ItemList);
            decimal totalAmount = Biller.CalculateTotalAmount(ItemList);
            Receipt = Biller.CreateNewReceipt(ItemList, totalTax, totalAmount);
            return Receipt;
        }

        public void PrintReceipt(Receipt Receipt)
        {
            Biller.GenerateReceipt(Receipt);
        }

        public Biller GetBiller(String Strategy)
        {
            TaxCalculatorFactory factory = new TaxCalculatorFactory();
            ITaxCalculator taxCalculation = factory.GetTaxCalculator(Strategy);
            return new Biller(taxCalculation);
        }
    }
}
