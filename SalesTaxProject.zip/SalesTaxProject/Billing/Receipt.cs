﻿using SalesTaxProject.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Billing
{
    public class Receipt
    {
        private List<Item> ItemList { get; set; }
        private decimal TotalTax { get; set; }
        private decimal TotalAmount { get; set; }

        public Receipt(List<Item> item, decimal tax, decimal amount)
        {
            ItemList = item;
            TotalTax = tax;
            TotalAmount = amount;
        }

        public int GetTotalNumberOfItems()
        {
            return ItemList.Count;
        }

        public override string ToString()
        {
            String receipt = "";
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("===================================");
            Console.ResetColor();
            Console.WriteLine("              RECEIPT              ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("===================================");
            Console.ResetColor();
            foreach (var p in ItemList)
            {
                receipt += String.Format("{0:0.00}\n", p.ToString());
            }

            receipt += String.Format("Sales Taxes: {0:0.00}\n", TotalTax);

            receipt += String.Format("Total: {0:0.00}\n", TotalAmount);
            
            return receipt;
        }
    }
}
