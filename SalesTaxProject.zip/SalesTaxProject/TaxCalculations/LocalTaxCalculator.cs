﻿using SalesTaxProject.utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.TaxCalculations
{
    
    // Total Tax Cost is calculated according as per local region specification.
    public class LocalTaxCalculator : ITaxCalculator
    {
        public decimal CalculateTax(decimal Price, decimal LocalTax, bool Import)
        {
            decimal tax = Price * LocalTax;

            if (Import)
                tax += (Price * 0.05M);

            //rounds off to nearest 0.05;
            tax = TaxUtil.RoundingOff(tax);

            return tax;
        }
    }
}
