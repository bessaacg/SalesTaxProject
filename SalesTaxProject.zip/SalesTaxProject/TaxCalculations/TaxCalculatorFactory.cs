﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace SalesTaxProject.TaxCalculations
{
    public class TaxCalculatorFactory
    {
        private Dictionary<String, ITaxCalculator> TaxCalculators;

        public TaxCalculatorFactory()
        {
            TaxCalculators = new Dictionary<string, ITaxCalculator>();
            RegisterInFactory("Local", new LocalTaxCalculator());
        }

        public void RegisterInFactory(string strategy, ITaxCalculator TaxCalculation)
        {
            TaxCalculators.Add(strategy, TaxCalculation);
        }

        public ITaxCalculator GetTaxCalculator(string strategy)
        {
            ITaxCalculator TaxCalculation = (ITaxCalculator)TaxCalculators[strategy];
            return TaxCalculation;
        }

        public int GetFactorySize()
        {
            return TaxCalculators.Count;
        }
    }
}
