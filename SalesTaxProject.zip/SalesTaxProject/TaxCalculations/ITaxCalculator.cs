﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.TaxCalculations
{
    
    /// Here there is computation of Total Tax Cost of a Product.
    /// </summary>
    public interface ITaxCalculator
    {
        /// Tax for a Product is calculated: where Tax Cost is the Sum of Sales 
        /// Tax and Import Duty of an Item.
        /// </summary>
        /// <param name="Price">The Price of the Item.</param>
        /// <param name="Tax">The Tax Rate of the Item.</param>
        /// <param name="Import">Item is whether an Import or not.</param>
        /// <returns></returns>
        decimal CalculateTax(decimal Price, decimal Tax, bool Import);
    }
}
