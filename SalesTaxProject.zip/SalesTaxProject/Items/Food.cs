﻿using SalesTaxProject.ItemFactories;
using SalesTaxProject.TaxCalculations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Items
{
    public class Food : Item
    {
        public Food() : base() {}

        public Food(string Name, decimal Price, bool Import, int Quantity)
            : base(Name, Price, Import, Quantity)
        {
        }

        public override ItemFactories.ItemFactory GetFactory()
        {
            return new FoodItemFactory();
        }

        public override decimal GetTaxValue(string Country)
        {
            return (Country == "Local") ? LocalTaxValues.FOOD_TAX : 0.0M;
        }
    }
}
