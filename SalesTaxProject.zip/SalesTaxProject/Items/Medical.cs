﻿using SalesTaxProject.ItemFactories;
using SalesTaxProject.TaxCalculations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Items
{
    public class Medical : Item
    {
        public Medical() : base() {}

        public Medical(string Name, decimal Price, bool Import, int Quantity)
            : base(Name, Price, Import, Quantity){}

        public override ItemFactories.ItemFactory GetFactory()
        {
            return new MedicalItemFactory();
        }

        public override decimal GetTaxValue(string Country)
        {
            return (Country == "Local") ? LocalTaxValues.MEDICAL_TAX : 0;
        }
    }
}
