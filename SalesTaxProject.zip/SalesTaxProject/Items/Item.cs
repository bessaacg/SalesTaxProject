﻿using SalesTaxProject.ItemFactories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.Items
{
    public abstract class Item
    {
        protected string Name { get; set; }
        private decimal _Price;

        public decimal Price
        {
            set { _Price = value; }
            get { return _Price * Quantity; }
        }

        public bool Import { get; set; }

        public int Quantity { get; set; }

        public decimal TaxedCost { get; set; }

        public Item()
        {
            this.Name = string.Empty;
            this.Price = 0.0M;
            this.Import = false;
            this.Quantity = 0;
            this.TaxedCost = 0.0M;
        }

        public Item(string Name, decimal Price, bool Import, int Quantity)
        {
            this.Name = Name;
            this.Price = Price;
            this.Import = Import;
            this.Quantity = Quantity;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} : {3}", Quantity, ImportToString(Import), Name, TaxedCost);
        }

        public String ImportToString(bool Import)
        {
            return (!Import) ? String.Empty : "imported";
        }

        public abstract ItemFactory GetFactory();

        public abstract decimal GetTaxValue(String country);
    }
}
