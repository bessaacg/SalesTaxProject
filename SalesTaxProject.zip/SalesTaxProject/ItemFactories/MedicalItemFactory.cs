﻿using SalesTaxProject.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxProject.ItemFactories
{
    public class MedicalItemFactory : ItemFactory
    {
        public override Items.Item CreateItem(string Name, decimal Price, bool Import, int Quantity)
        {
            return new Medical(Name, Price, Import, Quantity);
        }
    }
}
